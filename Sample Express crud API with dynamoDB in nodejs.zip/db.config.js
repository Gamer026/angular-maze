const AWS = require('aws-sdk');

AWS.config.update({
    region: "ap-northeast-1",
    accessKeyId: "AKIAXH6QNHO5CI52NWMD",
    secretAccessKey: "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"
})

const db = new AWS.DynamoDB.DocumentClient();

module.exports = {
    db
}