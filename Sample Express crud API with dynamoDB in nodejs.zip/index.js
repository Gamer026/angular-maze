const express = require('express')
const serverless = require('serverless-http');
const bodyParser = require('body-parser');
const app = express();
const multer = require('multer');
const port = 5000;
const { S3 } = require('aws-sdk');
const fs = require('fs');
const CORS = require('cors')
const { createOrUpdate, deleteUserById, getUserById, readAllUsers } = require('./db.js')

app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));

app.use(CORS());
const user = require('./routes.js');

const bucket = new S3(
  {
    accessKeyId: 'AKIAXH6QNHO5KUZXM3D2',
    secretAccessKey: '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',
    region: 'ap-south-1'
  }
);

// app.use(bodyParser.json());

// app.use(
//   bodyParser.urlencoded({
//     extended: true,
//   })
// );

app.set('view engine', 'ejs');

const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, "uploads") },
  filename: function (req, file, cb) {
    // console.log("file",file); 
    let nameFile = file?.originalname;
    cb(null, nameFile)
  }
})

const upload = multer({ storage: storage });


app.post('/upload', upload.single('pics'), (request, response) => {
  console.log("uploadedFile=>", request?.file);
  console.log("body",request?.body);

  const params = {
    Bucket: 'lambdafunctionbucketfortest',
    Key: request?.file?.filename,
    Body: fs.createReadStream(request?.file?.path),
    ACL: 'public-read',
    ContentType: request?.file?.mimetype
  };

  bucket.upload(params, async function (err, data) {
    if (err) {
      console.log('There was an error uploading your file: ', err);
      response.status(200).json({ Status: "Failed to Upload the File, Please try again...", Error: err })
      return false;
    }
    // response.status(200).json({ Status: "File Uploaded SuccessFully", FileName: params?.Key, fileURL: data?.Location })
    console.log('Successfully uploaded file.', data);

    let bookDetails = request.body;
    let id = newuser()
    bookDetails = {...bookDetails, fileUrl:data?.Location, student_id:id}
    const { success, result, msg } = await createOrUpdate(bookDetails);
  
    if (success) {
      return response.json({ success, result })
    } else {
      return response.status(500).json({ success: false, messsage: "Error", error: msg })
    }
    // return true;

  });

})

app.get('/', (req, res) => {
  res.status(200).json('Node.js is running successfully')
})

app.get('/html', (req, res) => {
  res.render('index');
});


app.post('/newBook', async (req, res) => {
 
});

app.get('/users', async (req, res) => {
  const { success, data, err } = await readAllUsers()

  if (success) {
    return res.json({ success, data })
  } else {
    return res.status(500).json({ success: false, messsage: "Error", error: err })
  }
})

app.post('/getBook', async (req, res) => {
  const bookData = req.body
  const { success, data } = await getUserById(bookData)
  console.log(data)
  if (success) {
    return res.json({ success, data })
  } else {
    return res.status(500).json({ success: false, message: "Error" })
  }
})

app.post('/book/delete', async (req,res)=>{
  console.log("req",req.body);
  const params = req?.body
    const { success, data } = await deleteUserById(params)
    if (success) {
      return res.json({ success, data })
    }
    return res.status(500).json({ success: false, message: 'Error',data:data})
})







app.use('/api', user)

const newuser = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0,
      v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

if (process.env.ENVIRONMENT === 'production') {
  module.exports.handler = serverless(app);
} else {
  app.listen(port, '192.168.1.163', () => {
    console.log('App runnig successfully at port 5000')
  })
}
