const {db,} = require('./db.config');
const Table = 'Student'
// Create or Update users
const createOrUpdate = async (data = {}) =>{
    const params = {
        TableName: Table,
        Item: data
    }
    // console.log("params",params);

    try{
        await db.put(params).promise()
        return { success: true }
    } catch(error){
        return { success: false,data:null, 'msg':error}
    }
}

// Read all users
const readAllUsers = async()=>{
    const params = {
        TableName: Table
    }
    // console.log("params",params);

    try{
        const { Items = [] } = await db.scan(params).promise();
        // console.log("item",Items);
        return { success: true, data: Items }

    } catch(error){
        return { success: false, data: null,err:error }
    }

}

// Read Users by ID
const getUserById = async (value) => {
    console.log("student_id",value);
    const params = {
        TableName: Table,
        Key: {
            "student_id": value?.student_id,
            "student_name":value?.student_name
        }
    }
    try {
        const { Item = {} } =  await db.get(params).promise()
        return { success: true, data: Item }
    } catch (error) {
        console.log("error",error);
        return {  success: false, data: null,err:error}     
    }
}

// Delete User by ID
const deleteUserById = async(value) => { 
    const params = {
        TableName: Table,
        Key: {
            student_id: value?.student_id,
            student_name: value?.student_name
        }
    }

    try {
        await db.delete(params).promise()
        return {  success: true }

    } catch (error) {
        return{ success: false,data:error }
    }
}


module.exports = {
    createOrUpdate,
    readAllUsers,
    getUserById,
    deleteUserById
}